import { openai } from "@ai-sdk/openai"
import { streamText } from "ai"

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

// Sample purchase history data that would normally come from a database
const purchaseHistory = [
  { id: 1, name: "Wireless Headphones", price: 129.99, date: "2023-04-15", category: "Electronics" },
  { id: 2, name: "Running Shoes", price: 89.95, date: "2023-04-02", category: "Sports" },
  { id: 3, name: "Coffee Maker", price: 59.99, date: "2023-03-28", category: "Home" },
  { id: 4, name: "Smartphone", price: 899.99, date: "2023-03-15", category: "Electronics" },
  { id: 5, name: "Yoga Mat", price: 29.95, date: "2023-03-10", category: "Sports" },
]

// Sample product catalog that would normally come from a database or API
const productCatalog = [
  {
    id: 101,
    name: "Bluetooth Speaker",
    price: 79.99,
    category: "Electronics",
    description: "Portable wireless speaker with 20-hour battery life",
  },
  {
    id: 102,
    name: "Fitness Tracker",
    price: 49.95,
    category: "Sports",
    description: "Tracks steps, heart rate, and sleep patterns",
  },
  {
    id: 103,
    name: "Smart Water Bottle",
    price: 24.99,
    category: "Sports",
    description: "Reminds you to stay hydrated throughout the day",
  },
  {
    id: 104,
    name: "Wireless Earbuds",
    price: 89.99,
    category: "Electronics",
    description: "True wireless earbuds with noise cancellation",
  },
  {
    id: 105,
    name: "Smart Coffee Mug",
    price: 39.99,
    category: "Home",
    description: "Keeps your coffee at the perfect temperature",
  },
  {
    id: 106,
    name: "Laptop Stand",
    price: 29.99,
    category: "Electronics",
    description: "Ergonomic stand for better posture while working",
  },
  {
    id: 107,
    name: "Resistance Bands",
    price: 19.95,
    category: "Sports",
    description: "Set of 5 bands for home workouts",
  },
  {
    id: 108,
    name: "Air Purifier",
    price: 149.99,
    category: "Home",
    description: "HEPA filter removes 99.97% of airborne particles",
  },
  {
    id: 109,
    name: "Wireless Charging Pad",
    price: 34.99,
    category: "Electronics",
    description: "Fast wireless charging for compatible devices",
  },
  {
    id: 110,
    name: "Smart Thermostat",
    price: 199.99,
    category: "Home",
    description: "Learn your preferences and save energy",
  },
]

export async function POST(req: Request) {
  const { messages } = await req.json()

  // Create a system message with purchase history and product catalog
  const systemMessage = `
    You are a helpful product recommendation assistant. 
    
    The user has the following purchase history:
    ${purchaseHistory.map((p) => `- ${p.name} (${p.category}) - $${p.price} - Purchased on ${p.date}`).join("\n")}
    
    You have access to the following product catalog:
    ${productCatalog.map((p) => `- ${p.name} (${p.category}) - $${p.price} - ${p.description}`).join("\n")}
    
    Based on their purchase history, recommend relevant products from the catalog.
    Be conversational and helpful. If they ask about products not in the catalog,
    you can make general recommendations but clarify that those specific products
    aren't in your current inventory.
    
    Always format product recommendations with the name, price, and a brief explanation
    of why you're recommending it based on their purchase history.
  `

  const result = streamText({
    model: openai("gpt-4o"),
    messages,
    system: systemMessage,
  })

  return result.toDataStreamResponse()
}
