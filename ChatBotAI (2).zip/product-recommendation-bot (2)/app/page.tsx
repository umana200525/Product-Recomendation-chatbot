import DashboardLayout from "./dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, TrendingUp, ShoppingBag, Star } from "lucide-react"
import Link from "next/link"

// Mock data for recent purchases
const recentPurchases = [
  { id: 1, name: "Wireless Headphones", price: 129.99, date: "2023-04-15", category: "Electronics" },
  { id: 2, name: "Running Shoes", price: 89.95, date: "2023-04-02", category: "Sports" },
  { id: 3, name: "Coffee Maker", price: 59.99, date: "2023-03-28", category: "Home" },
]

// Mock data for recommended products
const recommendedProducts = [
  { id: 101, name: "Bluetooth Speaker", price: 79.99, category: "Electronics", match: "98%" },
  { id: 102, name: "Fitness Tracker", price: 49.95, category: "Sports", match: "95%" },
  { id: 103, name: "Smart Water Bottle", price: 24.99, category: "Sports", match: "92%" },
]

export default function Home() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col justify-between space-y-2 md:flex-row md:items-center md:space-y-0">
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <div className="flex items-center space-x-2">
            <Link href="/chat">
              <Button>
                Get Recommendations
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Purchases</CardTitle>
              <ShoppingBag className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24</div>
              <p className="text-xs text-muted-foreground">+12% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Favorite Category</CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">Electronics</div>
              <p className="text-xs text-muted-foreground">Based on 8 purchases</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Recommendation Accuracy</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">94%</div>
              <p className="text-xs text-muted-foreground">+2% from last month</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Recent Purchases</CardTitle>
              <CardDescription>Your latest product purchases</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentPurchases.map((purchase) => (
                  <div key={purchase.id} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{purchase.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {purchase.category} • {purchase.date}
                      </p>
                    </div>
                    <p className="font-medium">${purchase.price}</p>
                  </div>
                ))}
                <Link href="/purchase-history">
                  <Button variant="outline" className="w-full">
                    View All Purchases
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Recommended For You</CardTitle>
              <CardDescription>Based on your purchase history</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recommendedProducts.map((product) => (
                  <div key={product.id} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted-foreground">{product.category}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">${product.price}</p>
                      <p className="text-xs text-green-500">{product.match} match</p>
                    </div>
                  </div>
                ))}
                <Link href="/chat">
                  <Button variant="outline" className="w-full">
                    Get More Recommendations
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
