import DashboardLayout from "../dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function ProfilePage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Your Profile</h2>
          <p className="text-muted-foreground">Manage your account and preferences</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>Your account details and preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center space-x-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage src="/placeholder.svg?height=80&width=80" alt="User" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-xl font-medium">John Doe</h3>
                  <p className="text-sm text-muted-foreground">john.doe@example.com</p>
                  <Button variant="link" className="h-auto p-0 text-sm">
                    Change profile picture
                  </Button>
                </div>
              </div>

              <div className="space-y-1">
                <h4 className="text-sm font-medium">Member Since</h4>
                <p>January 15, 2023</p>
              </div>

              <div className="space-y-1">
                <h4 className="text-sm font-medium">Location</h4>
                <p>New York, USA</p>
              </div>

              <Button>Edit Profile</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Shopping Preferences</CardTitle>
              <CardDescription>Your preferred categories and interests</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Favorite Categories</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge>Electronics</Badge>
                  <Badge>Sports</Badge>
                  <Badge>Home</Badge>
                  <Badge variant="outline">Books</Badge>
                  <Badge variant="outline">Fashion</Badge>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Price Range</h4>
                <p>$50 - $500</p>
              </div>

              <div className="space-y-2">
                <h4 className="text-sm font-medium">Recommendation Settings</h4>
                <div className="space-y-1">
                  <p className="text-sm">Email recommendations: Weekly</p>
                  <p className="text-sm">Push notifications: On</p>
                  <p className="text-sm">Similar product alerts: On</p>
                </div>
              </div>

              <Button>Update Preferences</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
