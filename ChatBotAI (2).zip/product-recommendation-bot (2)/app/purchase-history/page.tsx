import DashboardLayout from "../dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search } from "lucide-react"

// Mock data for purchase history
const purchaseHistory = [
  { id: 1, name: "Wireless Headphones", price: 129.99, date: "2023-04-15", category: "Electronics" },
  { id: 2, name: "Running Shoes", price: 89.95, date: "2023-04-02", category: "Sports" },
  { id: 3, name: "Coffee Maker", price: 59.99, date: "2023-03-28", category: "Home" },
  { id: 4, name: "Smartphone", price: 899.99, date: "2023-03-15", category: "Electronics" },
  { id: 5, name: "Yoga Mat", price: 29.95, date: "2023-03-10", category: "Sports" },
  { id: 6, name: "Blender", price: 49.99, date: "2023-02-28", category: "Home" },
  { id: 7, name: "Laptop", price: 1299.99, date: "2023-02-15", category: "Electronics" },
  { id: 8, name: "Fitness Tracker", price: 79.95, date: "2023-02-05", category: "Sports" },
  { id: 9, name: "Air Purifier", price: 149.99, date: "2023-01-28", category: "Home" },
  { id: 10, name: "Wireless Earbuds", price: 89.99, date: "2023-01-15", category: "Electronics" },
]

export default function PurchaseHistory() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col justify-between space-y-2 md:flex-row md:items-center md:space-y-0">
          <h2 className="text-3xl font-bold tracking-tight">Purchase History</h2>
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search purchases..." className="pl-8" />
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Your Purchase History</CardTitle>
            <CardDescription>A record of all your past purchases</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {purchaseHistory.map((purchase) => (
                <div
                  key={purchase.id}
                  className="flex flex-col justify-between border-b pb-4 last:border-0 last:pb-0 sm:flex-row"
                >
                  <div>
                    <p className="font-medium">{purchase.name}</p>
                    <div className="flex items-center space-x-2">
                      <p className="text-sm text-muted-foreground">{purchase.date}</p>
                      <Badge variant="outline">{purchase.category}</Badge>
                    </div>
                  </div>
                  <div className="mt-2 sm:mt-0 sm:text-right">
                    <p className="font-medium">${purchase.price}</p>
                    <Button variant="link" size="sm" className="h-auto p-0 text-sm">
                      View Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
