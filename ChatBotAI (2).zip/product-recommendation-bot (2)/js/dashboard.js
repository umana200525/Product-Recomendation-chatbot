document.addEventListener("DOMContentLoaded", () => {
  // Mock data for purchaseHistory and productCatalog
  const purchaseHistory = [
    { name: "Awesome T-Shirt", category: "Apparel", date: "2024-01-20", price: 25 },
    { name: "Cool Coffee Mug", category: "Home Goods", date: "2024-01-15", price: 12 },
    { name: "Stylish Backpack", category: "Accessories", date: "2024-01-10", price: 40 },
    { name: "Another T-Shirt", category: "Apparel", date: "2024-01-05", price: 20 },
  ]

  const productCatalog = [
    { name: "Amazing Watch", category: "Accessories", price: 100, match: 95 },
    { name: "Comfortable Shoes", category: "Footwear", price: 80, match: 80 },
    { name: "Durable Headphones", category: "Electronics", price: 150, match: 70 },
    { name: "Ergonomic Keyboard", category: "Electronics", price: 75, match: 60 },
  ]

  // Load recent purchases
  const recentPurchasesContainer = document.getElementById("recent-purchases")
  if (recentPurchasesContainer) {
    // Get the 3 most recent purchases
    const recentPurchases = purchaseHistory.slice(0, 3)

    recentPurchases.forEach((purchase) => {
      const purchaseItem = document.createElement("div")
      purchaseItem.className = "purchase-item"
      purchaseItem.innerHTML = `
                <div class="purchase-details">
                    <span class="purchase-name">${purchase.name}</span>
                    <span class="purchase-meta">${purchase.category} • ${purchase.date}</span>
                </div>
                <span class="purchase-price">$${purchase.price}</span>
            `
      recentPurchasesContainer.appendChild(purchaseItem)
    })
  }

  // Load recommended products
  const recommendedProductsContainer = document.getElementById("recommended-products")
  if (recommendedProductsContainer) {
    // Get the 3 most recommended products
    const recommendedProducts = productCatalog.slice(0, 3)

    recommendedProducts.forEach((product) => {
      const productItem = document.createElement("div")
      productItem.className = "recommendation-item"
      productItem.innerHTML = `
                <div class="recommendation-details">
                    <span class="recommendation-name">${product.name}</span>
                    <span class="recommendation-meta">${product.category}</span>
                </div>
                <div>
                    <span class="recommendation-price">$${product.price}</span>
                    <span class="recommendation-match">${product.match} match</span>
                </div>
            `
      recommendedProductsContainer.appendChild(productItem)
    })
  }
})
