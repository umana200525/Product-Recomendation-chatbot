document.addEventListener("DOMContentLoaded", () => {
  const purchaseHistoryContainer = document.getElementById("purchase-history")
  const searchInput = document.getElementById("search-purchases")

  // Sample purchase history data (replace with actual data source)
  const purchaseHistory = [
    { name: "Laptop", date: "2023-01-15", category: "Electronics", price: 1200 },
    { name: "Office Chair", date: "2023-02-20", category: "Furniture", price: 250 },
    { name: "Wireless Mouse", date: "2023-03-10", category: "Electronics", price: 30 },
    { name: "Desk Lamp", date: "2023-04-05", category: "Furniture", price: 45 },
    { name: "Keyboard", date: "2023-05-12", category: "Electronics", price: 75 },
  ]

  // Function to render purchase history
  function renderPurchaseHistory(purchases) {
    purchaseHistoryContainer.innerHTML = ""

    if (purchases.length === 0) {
      purchaseHistoryContainer.innerHTML = "<p>No purchases found.</p>"
      return
    }

    purchases.forEach((purchase) => {
      const purchaseItem = document.createElement("div")
      purchaseItem.className = "purchase-history-item"

      purchaseItem.innerHTML = `
                <div class="purchase-history-details">
                    <div>
                        <span class="purchase-name">${purchase.name}</span>
                        <div class="purchase-history-meta">
                            <span class="purchase-meta">${purchase.date}</span>
                            <span class="badge primary">${purchase.category}</span>
                        </div>
                    </div>
                    <div>
                        <span class="purchase-price">$${purchase.price}</span>
                        <a href="#" class="link-btn">View Details</a>
                    </div>
                </div>
            `

      purchaseHistoryContainer.appendChild(purchaseItem)
    })
  }

  // Initial render
  renderPurchaseHistory(purchaseHistory)

  // Search functionality
  if (searchInput) {
    searchInput.addEventListener("input", function () {
      const searchTerm = this.value.toLowerCase()

      const filteredPurchases = purchaseHistory.filter((purchase) => {
        return purchase.name.toLowerCase().includes(searchTerm) || purchase.category.toLowerCase().includes(searchTerm)
      })

      renderPurchaseHistory(filteredPurchases)
    })
  }
})
