// Sidebar functionality
document.addEventListener("DOMContentLoaded", () => {
  const sidebar = document.getElementById("sidebar")
  const toggleSidebar = document.getElementById("toggle-sidebar")
  const closeSidebar = document.getElementById("close-sidebar")

  // Toggle sidebar on mobile
  if (toggleSidebar) {
    toggleSidebar.addEventListener("click", () => {
      sidebar.classList.toggle("active")
    })
  }

  // Close sidebar on mobile
  if (closeSidebar) {
    closeSidebar.addEventListener("click", () => {
      sidebar.classList.remove("active")
    })
  }

  // Close sidebar when clicking outside on mobile
  document.addEventListener("click", (event) => {
    const isClickInsideSidebar = sidebar.contains(event.target)
    const isClickOnToggle = toggleSidebar && toggleSidebar.contains(event.target)

    if (!isClickInsideSidebar && !isClickOnToggle && window.innerWidth <= 768) {
      sidebar.classList.remove("active")
    }
  })

  // Handle window resize
  window.addEventListener("resize", () => {
    if (window.innerWidth > 768) {
      sidebar.classList.remove("active")
    }
  })
})
