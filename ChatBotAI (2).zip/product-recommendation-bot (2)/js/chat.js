document.addEventListener("DOMContentLoaded", () => {
  const chatMessages = document.getElementById("chat-messages");
  const chatForm = document.getElementById("chat-form");
  const chatInput = document.getElementById("chat-input");

  // Gemini API configuration
  const GEMINI_API_KEY = "AIzaSyATwFKbXnQVjXbXUyxxL-N4kX2fTYmS3lc";
  const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`;

  // Define botResponses object
  const botResponses = {
    greeting: "Hello! I'm your AI-powered shopping assistant. How can I help you today?",
    loading: "I'm analyzing our product catalog to find the best options for you...",
    apiError: "I'm having trouble accessing our full product database right now. Here's what I can tell you:",
    fallback: "I want to make sure I understand your request. Could you provide more details?",
  };

  // Enhanced productCatalog array
  const productCatalog = [
    {
      name: "Smart TV",
      category: "Electronics",
      price: 499.99,
      description: "55-inch 4K Ultra HD Smart TV with HDR and built-in streaming apps.",
      features: ["4K resolution", "Smart platform", "HDR support", "Multiple HDMI ports"],
      popular: true
    },
    {
      name: "Wireless Earbuds",
      category: "Electronics",
      price: 129.99,
      description: "Premium wireless earbuds with active noise cancellation.",
      features: ["Bluetooth 5.0", "24hr battery", "IPX4 water resistance", "Touch controls"],
      popular: true
    },
    {
      name: "Gaming Laptop",
      category: "Electronics",
      price: 1499.99,
      description: "High-performance gaming laptop with RGB keyboard.",
      features: ["RTX 3060 GPU", "16GB RAM", "144Hz display", "1TB SSD"],
      popular: true
    },
    {
      name: "Smartphone",
      category: "Electronics",
      price: 799.99,
      description: "Flagship smartphone with triple camera system.",
      features: ["6.7\" AMOLED", "128GB storage", "5G capable", "Wireless charging"],
      popular: true
    },
    {
      name: "Fitness Tracker",
      category: "Electronics",
      price: 89.99,
      description: "Waterproof fitness tracker with heart rate monitor.",
      features: ["Sleep tracking", "7-day battery", "Smart notifications", "15 exercise modes"],
      popular: true
    },
    {
      name: "Robot Vacuum",
      category: "Home",
      price: 299.99,
      description: "Smart robot vacuum with app control and mapping.",
      features: ["Lidar navigation", "Self-charging", "Voice control", "Pet hair brush"],
      popular: true
    },
    {
      name: "Air Fryer",
      category: "Home",
      price: 89.99,
      description: "Digital air fryer with multiple cooking functions.",
      features: ["5.8QT capacity", "8 presets", "Non-stick basket", "Auto shut-off"],
      popular: true
    },
    {
      name: "Stand Mixer",
      category: "Home",
      price: 349.99,
      description: "Professional-grade stand mixer for baking.",
      features: ["10 speeds", "5.5QT bowl", "Tilt-head design", "3 included attachments"],
      popular: true
    },
    
    {
      name: "who created this chatbot",
      category: "Home",
    
      description: "Chandramohan , shiva ,happy",
      features: ["we added html css and javascript for this chatbot."],
      popular: true
    },
    {
      name: "Running Shoes",
      category: "Sports",
      price: 119.99,
      description: "Lightweight running shoes with responsive cushioning.",
      features: ["Breathable mesh", "Carbon rubber sole", "Arch support", "Reflective details"],
      popular: true
    },
    {
      name: "Yoga Mat",
      category: "Sports",
      price: 29.99,
      description: "Extra-thick non-slip yoga mat.",
      features: ["6mm thickness", "Eco-friendly", "Carry strap", "Alignment markers"],
      popular: true
    },
    {
      name: "Dumbbell Set",
      category: "Sports",
      price: 149.99,
      description: "Adjustable dumbbell set with storage rack.",
      features: ["5-50lbs", "Quick-change", "Non-slip grips", "Compact design"],
      popular: true
    },
    {
      name: "Wireless Gaming Mouse",
      category: "Gaming",
      price: 59.99,
      description: "High-precision wireless gaming mouse with RGB lighting.",
      features: ["16000 DPI", "6 Programmable Buttons", "Rechargeable Battery", "RGB Lighting"],
      popular: true
    },
    {
      name: "Mechanical Gaming Keyboard",
      category: "Gaming",
      price: 89.99,
      description: "RGB mechanical keyboard with customizable keys.",
      features: ["Blue Switches", "Full RGB Backlighting", "Anti-Ghosting", "Detachable Cable"],
      popular: true
    },
    {
      name: "4K Smart TV 55\"",
      category: "Electronics",
      price: 499.99,
      description: "Ultra HD 4K Smart TV with built-in apps.",
      features: ["HDR10", "Voice Control", "Wi-Fi", "Multiple HDMI Ports"],
      popular: true
    },
    {
      name: "Bluetooth Soundbar",
      category: "Electronics",
      price: 129.99,
      description: "Wireless soundbar with subwoofer for home theaters.",
      features: ["Surround Sound", "Remote Control", "HDMI ARC", "Wall Mountable"],
      popular: false
    },
    {
      name: "Gaming Headset",
      category: "Gaming",
      price: 74.99,
      description: "Surround sound headset with mic for immersive gameplay.",
      features: ["Noise Cancellation", "LED Lights", "Comfort Fit", "Detachable Mic"],
      popular: true
    },
    {
      name: "VR Headset",
      category: "Gaming",
      price: 349.99,
      description: "Virtual Reality headset compatible with PC and consoles.",
      features: ["360° Tracking", "Ergonomic Design", "HD Lenses", "Adjustable Straps"],
      popular: true
    },
    {
      name: "Portable Bluetooth Speaker",
      category: "Electronics",
      price: 49.99,
      description: "Waterproof speaker with deep bass and 12-hour playtime.",
      features: ["IPX7 Waterproof", "USB-C Charging", "Bluetooth 5.0", "Stereo Pairing"],
      popular: true
    },
    {
      name: "External SSD 1TB",
      category: "Electronics",
      price: 109.99,
      description: "High-speed portable SSD with USB-C interface.",
      features: ["1050MB/s Read Speed", "Shock Resistant", "Compact Design", "Compatible with Mac/PC"],
      popular: true
    },
    {
      name: "Gaming Chair",
      category: "Gaming",
      price: 189.99,
      description: "Ergonomic gaming chair with lumbar support.",
      features: ["Reclining Back", "PU Leather", "Headrest", "360° Swivel"],
      popular: false
    },
    {
      name: "Smartwatch",
      category: "Electronics",
      price: 149.99,
      description: "Fitness and notification tracking smartwatch.",
      features: ["Heart Rate Monitor", "Sleep Tracking", "GPS", "Water Resistant"],
      popular: true
    },
    {
      name: "Gaming Console",
      category: "Gaming",
      price: 399.99,
      description: "Next-gen console with 4K gaming and exclusive titles.",
      features: ["Ultra-Fast Load Times", "HDR Support", "Wireless Controller", "8K Capability"],
      popular: true
    },
    {
      name: "Noise-Cancelling Headphones",
      category: "Electronics",
      price: 199.99,
      description: "Over-ear wireless headphones with ANC.",
      features: ["Active Noise Canceling", "30-Hour Battery", "Touch Controls", "Hi-Res Audio"],
      popular: true
    },
    {
      name: "Smartphone Gimbal",
      category: "Electronics",
      price: 99.99,
      description: "3-axis handheld stabilizer for smartphones.",
      features: ["Auto Tracking", "Portable Design", "Gesture Control", "App Integration"],
      popular: false
    },
    {
      name: "Gaming Monitor 27\"",
      category: "Gaming",
      price: 279.99,
      description: "144Hz gaming monitor with 1ms response time.",
      features: ["G-Sync Compatible", "IPS Panel", "HDMI/DP Ports", "HDR Support"],
      popular: true
    },
    {
      name: "Streaming Webcam",
      category: "Electronics",
      price: 79.99,
      description: "Full HD 1080p webcam for content creators.",
      features: ["Built-in Mic", "Adjustable Angle", "Plug & Play", "Low Light Correction"],
      popular: true
    },
    {
      name: "Smart Home Assistant",
      category: "Electronics",
      price: 89.99,
      description: "Voice-controlled smart speaker with AI assistant.",
      features: ["Multi-Room Audio", "Voice Match", "Smart Home Control", "Compact Design"],
      popular: true
    },
    {
      name: "Gaming Controller",
      category: "Gaming",
      price: 59.99,
      description: "Wireless controller with customizable buttons.",
      features: ["Haptic Feedback", "Bluetooth", "Ergonomic Grip", "Rechargeable"],
      popular: false
    },
    {
      name: "Wireless Earbuds",
      category: "Electronics",
      price: 69.99,
      description: "In-ear Bluetooth earbuds with touch controls.",
      features: ["Noise Isolation", "Charging Case", "Sweat Resistant", "Voice Assistant"],
      popular: true
    },
    {
      name: "Gaming Capture Card",
      category: "Gaming",
      price: 129.99,
      description: "Capture card for live streaming and recording games.",
      features: ["1080p 60fps", "HDMI Passthrough", "Low Latency", "USB 3.0"],
      popular: false
    },
    {
      name: "Portable Projector",
      category: "Electronics",
      price: 229.99,
      description: "Mini projector for home and outdoor use.",
      features: ["1080p Resolution", "Wi-Fi/Bluetooth", "Built-in Speaker", "Remote Control"],
      popular: true
    },
    {
      name: "Gaming Laptop",
      category: "Gaming",
      price: 1199.99,
      description: "High-performance laptop for modern games.",
      features: ["RTX Graphics", "16GB RAM", "1TB SSD", "144Hz Display"],
      popular: true
    },
    {
      name: "Noise Meter",
      category: "Electronics",
      price: 39.99,
      description: "Digital sound level meter for accurate measurement.",
      features: ["Backlit LCD", "Max Hold Function", "Auto Power Off", "Compact Size"],
      popular: false
    },
    {
      name: "Gaming Desk",
      category: "Gaming",
      price: 249.99,
      description: "Spacious gaming desk with RGB lights.",
      features: ["Cup Holder", "Headphone Hook", "Carbon Fiber Surface", "Cable Management"],
      popular: true
    },
    {
      name: "Smart Light Strip",
      category: "Electronics",
      price: 34.99,
      description: "Color-changing LED strip with app control.",
      features: ["Voice Compatible", "Timer Function", "Sync to Music", "16 Million Colors"],
      popular: true
    },
    {
      name: "Gaming Mouse Pad",
      category: "Gaming",
      price: 29.99,
      description: "Extended RGB gaming mouse pad.",
      features: ["Anti-Slip Base", "Waterproof Surface", "USB Powered", "Soft Texture"],
      popular: false
    },
    {
      name: "Streaming Microphone",
      category: "Electronics",
      price: 89.99,
      description: "Professional USB mic for gaming and podcasts.",
      features: ["Cardioid Pickup", "Gain Control", "Mute Button", "Adjustable Stand"],
      popular: true
    },
    {
      name: "Gaming Glasses",
      category: "Gaming",
      price: 24.99,
      description: "Blue light blocking glasses for gamers.",
      features: ["UV Protection", "Lightweight Frame", "Anti-Reflective", "Stylish Design"],
      popular: false
    },
    {
      name: "Smart Thermostat",
      category: "Electronics",
      price: 149.99,
      description: "Energy-saving smart thermostat with app control.",
      features: ["Wi-Fi Enabled", "Touch Display", "Scheduling", "Voice Integration"],
      popular: true
    },
    {
      name: "Gaming Backpack",
      category: "Gaming",
      price: 59.99,
      description: "Backpack for carrying gaming laptops and gear.",
      features: ["Water-Resistant", "Padded Compartments", "USB Charging Port", "Durable Zippers"],
      popular: false
    },
    {
      name: "Robot Vacuum",
      category: "Electronics",
      price: 229.99,
      description: "Smart robotic vacuum with mapping and Wi-Fi.",
      features: ["App Scheduling", "Auto Charging", "Voice Compatible", "Obstacle Avoidance"],
      popular: true
    },
    {
      name: "Retro Game Console",
      category: "Gaming",
      price: 69.99,
      description: "Handheld console with classic games.",
      features: ["HDMI Output", "Rechargeable", "Over 500 Games", "Compact Design"],
      popular: true
    },
    {
      name: "Smart Plug",
      category: "Electronics",
      price: 19.99,
      description: "Wi-Fi smart plug for automation.",
      features: ["Voice Control", "Timer", "Energy Monitoring", "Compact Design"],
      popular: true
    },
    {
      name: "Gaming Steering Wheel",
      category: "Gaming",
      price: 199.99,
      description: "Racing wheel for simulation games.",
      features: ["Force Feedback", "Pedal Set", "Adjustable Sensitivity", "Mountable"],
      popular: true
    },
    {
      name: "E-Reader",
      category: "Electronics",
      price: 139.99,
      description: "Lightweight e-reader with high-res display.",
      features: ["Backlight", "Long Battery Life", "Glare-Free Screen", "Wi-Fi"],
      popular: false
    },
    {
      name: "Gaming Joystick",
      category: "Gaming",
      price: 79.99,
      description: "Joystick for flight simulator and arcade games.",
      features: ["Programmable Buttons", "Adjustable Resistance", "Ergonomic Grip", "USB Plug"],
      popular: false
    },
    {
      name: "Home Security Camera",
      category: "Electronics",
      price: 59.99,
      description: "Indoor camera with motion detection and cloud storage.",
      features: ["1080p Video", "Night Vision", "2-Way Audio", "App Alerts"],
      popular: true
    },
    {
      name: "Gaming Dock Station",
      category: "Gaming",
      price: 69.99,
      description: "Docking station for handheld gaming console.",
      features: ["HDMI Output", "USB Ports", "Cooling System", "Compact Design"],
      popular: false
    },
    {
      name: "Electric Scooter",
      category: "Sports",
      price: 399.99,
      description: "Foldable electric scooter for urban commuting.",
      features: ["18mph speed", "20mi range", "LED display", "App connectivity"],
      popular: true
    },
    {
      name: "Bluetooth Speaker",
      category: "Electronics",
      price: 79.99,
      description: "Portable waterproof Bluetooth speaker.",
      features: ["24hr playtime", "IP67 rating", "Party pairing", "Built-in mic"],
      popular: false
    },
    {
      name: "Espresso Machine",
      category: "Home",
      price: 199.99,
      description: "15-bar pressure espresso machine with milk frother.",
      features: ["Removable tank", "Fast heat-up", "Compact size", "Easy cleaning"],
      popular: false
    },
    {
      name: "Projector",
      category: "Electronics",
      price: 299.99,
      description: "Full HD 1080p home theater projector.",
      features: ["4K support", "5000:1 contrast", "Built-in speakers", "Keystone correction"],
      popular: false
    },
    {
      name: "Electric Blanket",
      category: "Home",
      price: 59.99,
      description: "Queen-size electric blanket with dual controls.",
      features: ["10 heat settings", "Auto shut-off", "Machine washable", "3hr preheat"],
      popular: false
    },
    {
      name: "Treadmill",
      category: "Sports",
      price: 899.99,
      description: "Folding treadmill with incline and Bluetooth.",
      features: ["12 preset programs", "2.5HP motor", "Device holder", "Shock absorption"],
      popular: false
    },
    {
      name: "Camping Tent",
      category: "Sports",
      price: 149.99,
      description: "4-person waterproof camping tent.",
      features: ["Easy setup", "Ventilation windows", "Rainfly included", "Gear loft"],
      popular: false
    }
  ];

  // Function to add a message to the chat
  function addMessage(content, isUser = false) {
    const messageDiv = document.createElement("div");
    messageDiv.className = `message ${isUser ? "user" : "bot"}`;
    messageDiv.innerHTML = `<div class="message-content">${content}</div>`;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  // Add initial bot message
  addMessage(botResponses.greeting);

  // Handle form submission
  if (chatForm) {
    chatForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const userMessage = chatInput.value.trim();
      
      if (!userMessage) return;

      addMessage(userMessage, true);
      chatInput.value = "";

      // Show typing indicator
      const typingIndicator = document.createElement("div");
      typingIndicator.className = "message bot typing-indicator";
      typingIndicator.innerHTML = `<div class="message-content">${botResponses.loading}</div>`;
      chatMessages.appendChild(typingIndicator);
      chatMessages.scrollTop = chatMessages.scrollHeight;

      try {
        // First try Gemini API
        const apiResponse = await getGeminiResponse(userMessage);
        chatMessages.removeChild(typingIndicator);
        addMessage(apiResponse);
      } catch (error) {
        console.error("API Error:", error);
        chatMessages.removeChild(typingIndicator);
        
        // Fallback to local response
        const localResponse = getLocalResponse(userMessage);
        addMessage(`${botResponses.apiError}<br><br>${localResponse}`);
      }
    });
  }

  // Improved local response system
  function getLocalResponse(userMessage) {
    const lowerMessage = userMessage.toLowerCase();
    
    // Check for specific product mentions
    const mentionedProduct = productCatalog.find(product => 
      lowerMessage.includes(product.name.toLowerCase())
    );
    
    if (mentionedProduct) {
      return `We have the ${mentionedProduct.name} ($${mentionedProduct.price}): 
              ${mentionedProduct.description}. 
              Key features: ${mentionedProduct.features.join(', ')}`;
    }
    
    // Check for categories
    if (/(tv|television|smart tv)/i.test(lowerMessage)) {
      const tvs = productCatalog.filter(p => 
        p.category === "Electronics" && p.name.toLowerCase().includes("tv")
      );
      if (tvs.length > 0) {
        return `We have these TV options: ${tvs.map(tv => 
          `${tv.name} ($${tv.price})`
        ).join(', ')}`;
      }
    }
    
    // General fallback
    return `Our store offers electronics, sports equipment, and home goods. 
            Could you specify what type of product you're looking for?`;
  }

  // Improved Gemini API call with better error handling
  async function getGeminiResponse(userMessage) {
    try {
      // Create a more compact product list for the prompt
      const productList = productCatalog.map(p => ({
        name: p.name,
        category: p.category,
        price: p.price,
        features: p.features.join(', ')
      }));
      
      const prompt = `You are a shopping assistant. Current products: ${JSON.stringify(productList)}. 
      User asked: "${userMessage}". Respond helpfully and concisely.`;
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);
      
      const response = await fetch(GEMINI_API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: prompt
            }]
          }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 500
          }
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
        throw new Error("No valid response from API");
      }
      
      return data.candidates[0].content.parts[0].text;
      
    } catch (error) {
      console.error("Gemini API Error:", error);
      throw error; // Re-throw to be caught in the form handler
    }
  }
});