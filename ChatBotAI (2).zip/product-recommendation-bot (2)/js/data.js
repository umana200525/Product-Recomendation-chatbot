// Sample data for the application

// Purchase history data
const purchaseHistory = [
  { id: 1, name: "Wireless Headphones", price: 129.99, date: "2023-04-15", category: "Electronics" },
  { id: 2, name: "Running Shoes", price: 89.95, date: "2023-04-02", category: "Sports" },
  { id: 3, name: "Coffee Maker", price: 59.99, date: "2023-03-28", category: "Home" },
  { id: 4, name: "Smartphone", price: 899.99, date: "2023-03-15", category: "Electronics" },
  { id: 5, name: "Yoga Mat", price: 29.95, date: "2023-03-10", category: "Sports" },
  { id: 6, name: "Blender", price: 49.99, date: "2023-02-28", category: "Home" },
  { id: 7, name: "Laptop", price: 1299.99, date: "2023-02-15", category: "Electronics" },
  { id: 8, name: "Fitness Tracker", price: 79.95, date: "2023-02-05", category: "Sports" },
  { id: 9, name: "Air Purifier", price: 149.99, date: "2023-01-28", category: "Home" },
  { id: 10, name: "Wireless Earbuds", price: 89.99, date: "2023-01-15", category: "Electronics" },
]

// Product catalog data
const productCatalog = [
  {
    id: 101,
    name: "Bluetooth Speaker",
    price: 79.99,
    category: "Electronics",
    description: "Portable wireless speaker with 20-hour battery life",
    match: "98%",
  },
  {
    id: 102,
    name: "Fitness Tracker",
    price: 49.95,
    category: "Sports",
    description: "Tracks steps, heart rate, and sleep patterns",
    match: "95%",
  },
  {
    id: 103,
    name: "Smart Water Bottle",
    price: 24.99,
    category: "Sports",
    description: "Reminds you to stay hydrated throughout the day",
    match: "92%",
  },
  {
    id: 104,
    name: "Wireless Earbuds",
    price: 89.99,
    category: "Electronics",
    description: "True wireless earbuds with noise cancellation",
    match: "90%",
  },
  {
    id: 105,
    name: "Smart Coffee Mug",
    price: 39.99,
    category: "Home",
    description: "Keeps your coffee at the perfect temperature",
    match: "88%",
  },
  {
    id: 106,
    name: "Laptop Stand",
    price: 29.99,
    category: "Electronics",
    description: "Ergonomic stand for better posture while working",
    match: "85%",
  },
  {
    id: 107,
    name: "Resistance Bands",
    price: 19.95,
    category: "Sports",
    description: "Set of 5 bands for home workouts",
    match: "82%",
  },
  {
    id: 108,
    name: "Air Purifier",
    price: 149.99,
    category: "Home",
    description: "HEPA filter removes 99.97% of airborne particles",
    match: "80%",
  },
  {
    id: 109,
    name: "Wireless Charging Pad",
    price: 34.99,
    category: "Electronics",
    description: "Fast wireless charging for compatible devices",
    match: "78%",
  },
  {
    id: 110,
    name: "Smart Thermostat",
    price: 199.99,
    category: "Home",
    description: "Learn your preferences and save energy",
    match: "75%",
  },
]

// Chat bot responses
const botResponses = {
  greeting:
    "Hello! I'm your personal shopping assistant. Based on your purchase history, I can recommend products you might like. What kind of products are you interested in today?",
  electronics:
    "Based on your purchase history, I see you've bought several electronics items. I'd recommend the Bluetooth Speaker ($79.99) which has excellent sound quality and battery life. Would you like more electronics recommendations?",
  sports:
    "I notice you've purchased sports equipment in the past. The Fitness Tracker ($49.95) would be a great addition to your collection. It tracks steps, heart rate, and sleep patterns. Would you like to know more about it?",
  home: "For your home, I'd recommend the Smart Coffee Mug ($39.99). It keeps your coffee at the perfect temperature, which would complement your Coffee Maker purchase. Would you like more home product recommendations?",
  price:
    "I can recommend products at various price points. The Resistance Bands ($19.95) are affordable and great for home workouts. On the higher end, the Smart Thermostat ($199.99) can help save energy costs in the long run. What's your budget range?",
  thanks:
    "You're welcome! I'm here to help whenever you need product recommendations. Is there anything else you'd like to know about our products?",
  fallback:
    "I'm not sure I understand. Could you please rephrase your question? I can help with product recommendations based on your purchase history, specific categories, or price ranges.",
}
